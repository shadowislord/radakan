These files can be used freely for non-commercial use but Dan White must be
credited for the creation of these files.
Please contact Dan White at DanBrianWhite@gmail.com if you wish to 
use these files for commericial use.